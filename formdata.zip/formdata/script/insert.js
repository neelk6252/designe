
<script>

    $('#sub').click(function(){
        var formdetails=$('#myForm').serialize();
        var url="postvalues.php";
        $.ajax({
            url:"../insert.php",
            data:"text",
            method:"POST",
            
        })
    });


    </script>
	