<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>Document</title>
</head>
<body>
<section>
<div class="container">
<form action="insert.php" method="post" id="myForm">
  <div class="form-group">
    <label for="forName">Name</label>
    <input type="text" class="form-control" id="forName" name="uname" placeholder="Enter Name" required>
  </div>
  <div class="form-group">
    <label for="forcity">City</label>
    <input type="text" class="form-control" id="forcity" name="city" placeholder="Enter City" required>
  </div>
  <div class="form-group">
    <label for="forOccupation">Occupation</label>
    <input type="text" class="form-control" id="forOccupation" name="occupation" placeholder="Enter Occupation" required> 
  </div>
 
  <button id="sub" type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</section>


<hr>






<section>
<div class="container">
<script src="script/insert.js"></script>
<div id="show"></div>
	
	<script type="text/javascript">
		$(document).ready(function() {
			setInterval(function () {
				$('#show').load('show.php')
			}, 1000);
		});
	</script>
</div>
</section>
</body>
<script src="script/jquery-1.8.1.min.js" type="text/javascript"></script>
</html>