<?php
include "db/config.php";
if (isset($_POST['submit'])) {

    $name = $_POST['uname'];
    $city = $_POST['city'];
    $occupation = $_POST['occupation'];
    $sql = "INSERT INTO formdata (name,city,occupation)
    VALUES ('$name','$city','$occupation')";
    if (mysqli_query($conn, $sql)) {
        header("Location: index.php");
    } else {
       echo "Error: " . $sql . "
" . mysqli_error($conn);
    }
    mysqli_close($conn);

}
?>