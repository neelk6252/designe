<?php 
include "db/config.php";

$result = $conn->query("SELECT name,city,occupation FROM formdata");
if ($result->num_rows > 0) { ?>

	<table class="table table-dark">
	<thead>
	  <tr>
		<th scope="col">Name</th>
		<th scope="col">City</th>
		<th scope="col">Occupation</th>
	  </tr>
	</thead>
	<tbody>
	<?php 
	while ($row = $result->fetch_assoc()) { 
		?>
	
    <tr>
      <td><?php echo $row['name']; ?></td>
      <td><?php echo $row['city']; ?></td>
      <td><?php echo $row['occupation']; ?></td>
    </tr>
  
		

	<?php
	}
}
?>
</tbody>
</table>